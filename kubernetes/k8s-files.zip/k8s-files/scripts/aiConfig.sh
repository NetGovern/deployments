#!/usr/bin/env bash

psql -v ON_ERROR_STOP=1 --username "$POSTGRES_USER" --dbname "$POSTGRES_DB" <<-EOSQL     

     CREATE TABLE aitask (taskid varchar(100),tenantid varchar(100), nipehost varchar(100), caseid varchar(100), endpoint varchar(100), errormsg varchar(800), status varchar(50), nbtaggeditems bigint,nbqueueditems bigint, totaltoprocess bigint, nbprocessed bigint,nberrors bigint, startdatetimems bigint, enddatetimems bigint, expiry bigint, expired boolean);

     CREATE TABLE nlptask (taskid varchar(50) PRIMARY KEY, docid varchar(100), expiry bigint, expired boolean, status boolean, res jsonb);

     CREATE TABLE aiprediction (predid BIGSERIAL PRIMARY KEY, docid varchar(100), taskid varchar(50), modeluid varchar(50),endpoint varchar(100), errormsg varchar(1000), timestamp bigint, score float, label varchar(50), expiry bigint, expired boolean);

     CREATE TABLE aidoc (taskid varchar(50), docid varchar(100), expiry bigint, expired boolean, text text, PRIMARY KEY(taskid, docid));

     CREATE INDEX pred_index ON aiprediction (predid asc);

     CREATE INDEX task_index ON aiprediction (taskid asc);

     CREATE INDEX prednlp_index ON nlptask (taskid asc);

EOSQL
